<?php

namespace App\Models;

use App\Core\Model;

class Login extends Model
{
	public function login(){
	
    $this->home('home/index');
  }
}