<?php

namespace App\Controllers;

use App\Core\Controller;

class Pelanggan extends Controller
{

      public function __construct()
      {
            $this->model = new \App\Models\Pelanggan();
      }

      public function index()
      {
            $data['rows'] = $this->model->all();
            $this->home('pelanggan/index', $data);
      }

      public function input()
      {
             $this->home('pelanggan/input');
      }
       public function store()
      {
            $this->model->store();
            header('location:' .  URL . '/pelanggan');
      }

      public function edit($id)
      {
            $data['row'] = $this->model->edit($id);
             $this->home('pelanggan/edit', $data);
      }

      public function update($id)
      {
            $this->model->update();
            header('location:' .  URL . '/pelanggan');
      }

      public function delete($id)
      {
            $this->model->delete($id);
             header('location:' .  URL . '/pelanggan');
      }
}
